/** Automatically generated file. DO NOT MODIFY */
package com.qq.test_login;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}